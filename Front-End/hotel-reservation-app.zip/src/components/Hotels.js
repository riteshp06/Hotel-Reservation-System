import React from 'react'

import HotelList from '../Hotels/HotelList';


const Hotels = () => {
  return (
    <div>
        <div>Hotels</div>
        <HotelList/>



    </div>
  )
}

export default Hotels;