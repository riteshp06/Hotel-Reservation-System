package com.project.springboothotelproject.enitites;

// Enum representing gender options
public enum Gender {
    MALE,
    FEMALE;
}
