package com.project.springboothotelproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHotelProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
